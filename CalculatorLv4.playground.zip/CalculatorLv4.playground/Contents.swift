import UIKit
/*
 Lv4
 - AbstractOperation라는 **추상화된** 클래스를 만들기
 - 기존에 구현한 AddOperation(더하기), SubtractOperation(빼기), MultiplyOperation(곱하기), DivideOperation(나누기) 클래스들과 관계를 맺고 Calculator 클래스의 내부 코드를 변경
 - 스위프트의 어떤 문법을 이용하여 추상화할 수 있을지 생각해 봅시다
 - Lv3 와 비교해서 어떠한 점이 개선 되었는지 스스로 생각해 봅니다.
     - hint. 클래스간의 결합도, 의존성(의존성역전원칙)
 */
class AbstractOperation {
    func cal() {
        print("추가")
    }
}

//더하기
class AddOperation: AbstractOperation {
    override func cal() {
        print("계산로직 추가")
    }
    //부모 클래스 메서드 오버로딩
    func cal(_ a: Int, _ b: Int) -> Int {
        return a + b
    }
}
//빼기
class SubstractOperation: AbstractOperation {
    override func cal() {
        print("계산로직 추가")
    }
    //부모 클래스 메서드 오버로딩
    func cal(_ a: Int, _ b: Int) -> Int {
        return a - b
    }
}
//곱하기
class MultiplyOperation: AbstractOperation {
    override func cal() {
        print("계산로직 추가")
    }
    //부모 클래스 메서드 오버로딩
    func cal(_ a: Int, _ b: Int) -> Int {
        return a * b
    }
}
//나누기
class DivideOperation: AbstractOperation {
    override func cal() {
        print("계산로직 추가")
    }
    //부모 클래스 메서드 오버로딩
    func cal(_ a: Int, _ b: Int) -> Int {
        return a / b
    }
}
//나머지
class RemainderOperation: AbstractOperation {
    override func cal() {
        print("계산로직 추가")
    }
    //부모 클래스 메서드 오버로딩
    func cal(_ a: Int, _ b: Int) -> Int {
        return a % b
    }
}

let addOperation = AddOperation()
addOperation.cal(10, 20)
let substractOperation = SubstractOperation()
substractOperation.cal(10, 20)
let multiplyOperation = MultiplyOperation()
multiplyOperation.cal(10, 20)
let divideOperation = DivideOperation()
divideOperation.cal(10, 20)
let remainerOper = RemainderOperation()
remainerOper.cal(10, 20)
