import UIKit

/*
 Lv3
 아래 각각의 클래스들을 만들고 클래스간의 관계를 고려하여 Calculator 클래스와 관계 맺기
 - AddOperation(더하기)
 - SubstractOperation(빼기)
 - MultiplyOperation(곱하기)
 - DivideOperation(나누기)
 Calculator 클래스의 내부코드를 변경
 - 관계를 맺은 후 필요하다면 별도로 만든 연산 클래스의 인스턴스를 Calculator 내부에서 사용
 - Lv2 와 비교하여 어떠한 점이 개선 되었는지 스스로 생각해 봅니다.
     - hint. 클래스의 책임(단일책임원칙)
*/
/*
class Calculator {
    func cal(_ sign :Character, _ a: Int, _ b: Int) -> Int {
        switch sign {
        case "+":
            return a + b
        case "-":
            return a - b
        case "*":
            return a * b
        case "/":
            return a / b
        case "%":
            return a % b
        default:
            return 0
        }
    }
}

//더하기
class AddOperation: Calculator {
    override func cal(_ sign: Character = "+", _ a: Int, _ b: Int) -> Int {
        return super.cal(sign, a, b)
    }
}

let addOperation = AddOperation()
addOperation.cal(10, 20)
*/

class Calculator {
    let addOper = AddOperation()
    let subOper = SubstractOperation()
    let multiOper = MultiplyOperation()
    let divOper = DivideOperation()
    let remainOper = RemainderOperation()
}

//더하기
class AddOperation {
    //더하기
    func add(_ a: Int, _ b: Int) -> Int {
        return a + b
    }
}
//빼기
class SubstractOperation {
    //빼기
    func sub(_ a: Int, _ b: Int) -> Int {
        return a - b
    }
}
//곱하기
class MultiplyOperation {
    //곱하기
    func mul(_ a: Int, _ b: Int) -> Int {
        return a * b
    }
}
//나누기
class DivideOperation {
    //나누기
    func div(_ a: Int, _ b: Int) -> Int {
        return a / b
    }
}
//나머지
class RemainderOperation {
    //나머지
    func remainder(_ a: Int, _ b: Int) -> Int {
        return a % b
    }
}
let cal = Calculator()
print(cal.addOper.add(10, 20))
print(cal.subOper.sub(10, 20))
print(cal.multiOper.mul(10, 20))
print(cal.divOper.div(10, 20))
print(cal.remainOper.remainder(10, 20))
