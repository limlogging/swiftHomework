import UIKit

/*
 Lv2
 Lv1에서 만든 Calculator 클래스에 “나머지 연산”이 가능하도록 코드를 추가하고, 연산 진행 후 출력
 ex) 나머지 연산 예시 : 6을 3으로 나눈 나머지는 0 / 5를 3으로 나눈 나머지는 2
*/
class Calculator {
    //더하기
    func add(_ a: Int, _ b: Int) -> Int {
        return a + b
    }
    //빼기
    func sub(_ a: Int, _ b: Int) -> Int {
        return a - b
    }
    //곱하기
    func mul(_ a: Int, _ b: Int) -> Int {
        return a * b
    }
    //나누기
    func div(_ a: Int, _ b: Int) -> Int {
        return a / b
    }
    //나머지
    func remainder(_ a: Int, _ b: Int) -> Int {
        return a % b
    }
}

let calculator = Calculator()
calculator.add(1, 2)
calculator.sub(3, 4)
calculator.mul(5, 6)
calculator.div(10, 2)
calculator.remainder(5, 3)
