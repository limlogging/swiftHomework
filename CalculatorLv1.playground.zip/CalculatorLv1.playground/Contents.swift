import UIKit

/*
 Lv1
 더하기, 빼기, 나누기, 곱하기 연산을 수행할 수 있는 Calculator 클래스를 만들기
 생성한 클래스를 이용하여 연산을 진행하고 출력
*/
class Calculator {
    //더하기
    func add(_ a: Int, _ b: Int) -> Int {
        return a + b
    }
    //빼기
    func sub(_ a: Int, _ b: Int) -> Int {
        return a - b
    }
    //곱하기
    func mul(_ a: Int, _ b: Int) -> Int {
        return a * b
    }
    //나누기
    func div(_ a: Int, _ b: Int) -> Int {
        return a / b
    }
}

let calculator = Calculator()
calculator.add(1, 2)
calculator.sub(3, 4)
calculator.mul(5, 6)
calculator.div(10, 2)
